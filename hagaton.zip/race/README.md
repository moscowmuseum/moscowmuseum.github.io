racing-game
===========

2D racing game written in JavaScript.

You can see the latest version in action <a href="http://urosh.net/race" target="_blank">here</a>.
Or you can try <a href="http://urosh.net/race/v1.0/" target="_blank">v1.0</a>.
